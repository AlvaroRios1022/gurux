<?php
session_start();
header("Content-Type: text/html;charset=utf-8");
ob_start();

if (!isset($_POST)) {
    die('Error, no exite el objeto POST.');
}
$post = $_POST;

if (!isset($post["tipo"])) {
    die('Error, no existe el dato "TIPO" el objeto POST.');
}

require_once(dirname(__FILE__) . "/../model/GuruModel.php");
$GLOBALS['path'] ='';
//$GLOBALS['path'] ='/guru17';
switch ($post['tipo']) {
    case "info_pesonal" :
        Informacion_Personal($post);
        break;
        case "formacion_academica" :
            Formacion_academica($post);
            break;
        case "estudio_complementario" :
            Estudio_complementario($post);
            break;
        case "experiencia_laboral":
            Experiencia_laboral($post);
        break;
        case "experiencia":
            Experiencia($post);
        break;
        case "idiomas":
            Idioma($post);
        break;
        case "UPLOAD":
            Upload($post);
        break;   
        case "terminos":
            terminos($post);
        break;
        case "eliminar_formacion":
            eliminar_formacion($post);
        break;
        case "eliminar_complementario":
            eliminar_complementario($post);
        break;
        case "eliminar_experiencia":
            eliminar_experiencia($post);
        break;
        case "eliminar_idioma":
            eliminar_idioma($post);
        break;
default: echo('Error, no existe el dato "TIPO" en el objeto POST');
    break;
}

function Upload($post){
    move_uploaded_file($_FILES  ['file']['tmp_name'], '../../temp/' . $_FILES['file']['name']);
     $path = $GLOBALS['path'];
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $data['Path'] = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/temp/' . $_FILES['file']['name'];
    $data['Name'] =  pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);;
    $data['status'] = 200;
    $data['state'] = true;
    $data['data'] = $data;
    echo json_encode($data); 
}

function eliminar_idioma($post){
    $respuesta = GuruModel::eliminar_idioma($post);
    echo json_encode($respuesta);
}

function eliminar_experiencia($post){
    $respuesta = GuruModel::eliminar_experiencia($post);
    echo json_encode($respuesta);
}

function eliminar_complementario($post){
    $respuesta = GuruModel::eliminar_complementario($post);
    echo json_encode($respuesta);
}
function eliminar_formacion($post){
    $respuesta = GuruModel::eliminar_formacion($post);
    echo json_encode($respuesta);
}

function Idioma($post){
    $respuesta = GuruModel::Idioma($post);
    echo json_encode($respuesta);
}

function Experiencia($post){

    
    $path = $GLOBALS['path'];
    $formato = explode(".",$post['url_cert_exp']);
    $ruta = dirname(__FILE__) .'/../../experiencia/'.date('YmdHis').'1.'.$formato[1];
    copy($post['url_cert_exp'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_imagen = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/experiencia/' .date('YmdHis').'1.'.$formato[1];
    $post['url_cert_exp']=$ruta_imagen;
    $respuesta = GuruModel::Experiencia($post);
    echo json_encode($respuesta);
}

function Experiencia_laboral($post){
    $respuesta = GuruModel::Experiencia_laboral($post);
    echo json_encode($respuesta);
}

function Formacion_academica($post){
    $path = $GLOBALS['path'];
    $formato = explode(".",$post['url_cert_formacion']);
    $ruta = dirname(__FILE__) .'/../../formacion_academica/'.date('YmdHis').'.'.$formato[1];
    copy($post['url_cert_formacion'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_imagen = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/formacion_academica/' .date('YmdHis').'.'.$formato[1];
    $post['url_cert_formacion']=$ruta_imagen;
    $respuesta = GuruModel::Formacion_academica($post);
    echo json_encode($respuesta);
}

function Informacion_Personal($post){
    $extencion = $post['url_image_name'];
    $url_image_name = $post['url_image_name'];
    $path = $GLOBALS['path'];
    $formato = explode(".",$post['url_image']);
    $formato2 = explode(".",$url_image_name);
    $ruta = dirname(__FILE__) .'/../../info_personal/'.$post['documento'].'.'.$extencion;
    copy($post['url_image'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_imagen = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/info_personal/' .$post['documento'].'.'.$extencion;
    $post['url_image']=$ruta_imagen;
    
    
    $ruta = dirname(__FILE__) .'/../../certificaciones/'.$post['documento'].'.pdf';
    copy($post['url_cert_formacion'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_pdf = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/certificaciones/' .$post['documento'].'.pdf';
    $post['url_cert_formacion']=$ruta_pdf;
    
    
    
    $respuesta = GuruModel::Informacion_Personal($post);
    echo json_encode($respuesta);
}

function Estudio_complementario($post){

    $path = $GLOBALS['path'];
    $formato = explode(".",$post['url_cert_adicional']);
    $ruta = dirname(__FILE__) .'/../../complementarios/'.date('YmdHis').'1.'.$formato[1];
    copy($post['url_cert_adicional'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_imagen = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/complementarios/' .date('YmdHis').'1.'.$formato[1];
    $post['url_cert_adicional']=$ruta_imagen;

    $path = $GLOBALS['path'];
    $formato = explode(".",$post['url_portafolio_adicional']);
    $ruta = dirname(__FILE__) .'/../../complementarios/'.date('YmdHis').'2.'.$formato[1];
    copy($post['url_portafolio_adicional'],$ruta);
    $protocol = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
    $ruta_imagen = $protocol."://".$_SERVER['HTTP_HOST'].$path.'/complementarios/' .date('YmdHis').'2.'.$formato[1];
    $post['url_portafolio_adicional']=$ruta_imagen;


    $respuesta = GuruModel::Estudio_complementario($post);
    echo json_encode($respuesta);
}

function terminos($post){
    $respuesta = GuruModel::terminos($post);
    echo json_encode($respuesta);
}

